## Status Tracking

| Item | Status | Updated | Notes |
|------|--------|---------|-------|
| Signal viz pipeline (6 SVGs) | Completed | 2026-03-27 | Delivered via catbox + ZIP |
| System of Systems SVG | Completed | 2026-03-27 | Light theme, uploaded |
| Brand system rebuild | Completed | 2026-03-27 | jotf_svg_constants.py + templates |
| Les Trois Mousquetaires | Completed | 2026-03-27 | Dark + light SVGs delivered |
| Structured memory system | Completed | 2026-04-02 | 3-tier architecture operational |
| Hamid's Mermaid styling | Completed | 2026-03-27 | Fixed #my-svg CSS scoping |
| Layer 1 GEO | Completed | 2026-04-02 | llms.txt, robots.txt, structured data deployed |
| Layer 2 GEO — Citability Audit | Completed | 2026-04-02 | Scores: Home 38, About 33, Oracle 42, Collisions 75 |
| Layer 2 GEO — Quick Wins | Pending | 2026-04-02 | 10 wins identified, none implemented yet |
| SID Channel Dig | Completed | 2026-04-02 | 5 patterns, 7 buried gold concepts, 5 action items |
| Skill formalization | Pending | 2026-04-01 | Write SKILL.md for wardley-map, jotf-diagram, mindmap |
| Oracle back-memory | Pending | 2026-04-01 | Track repeated collision themes across editions |
| Flash Facilitation packaging | Pending | 2026-04-02 | From SID dig — Hamid's 90-min workshop concept |
| infoDJ lineage on About page | Pending | 2026-04-02 | From SID dig — JediSignals provenance |
| LinkedIn collision cadence | Pending | 2026-04-02 | From SID dig — 1 collision per post |
| InnoGraph / Graph RAG | In Progress | 2026-04-05 | Hamid's weekend sprint. 1/3 corpus loaded, collision queries working. Neo4j + 15-attr nodes |
| Collision Daily (brand product) | Concept | 2026-04-05 | Lettermeme-inspired collision delivery. Depends on InnoGraph + signal stream. Cadence TBD (daily vs bi-weekly) |
| Jedi Signals — Multi-Signal Mode | Planned | 2026-04-06 | 1:many article→signals (3-5 per article). 30k articles → 90-150k signals. Claim-level resolution |
| Jedi Signals — Current Scale | Active | 2026-04-06 | ~30k articles ingested (Jan-Apr). ~10k/month rate. 3,000 taxonomy nodes, 12,000 aliases. 4 ontology layers: Technology, Application, Catalyst, Trend. Cost: $75-80/mo (laptop). Multi-signal: ~$150-200/mo. Full cloud+Neo4j+OSS LLM: $350-500/mo |
| Atomic Unit of Value — Pattern Library | Active | 2026-04-06 | 4 specimens: Lessin (summarize), Fishburne (encode), Neeley (curate), JOTF (collide). Living reference |
| Futures Wheel — MTP Beta | In Progress | 2026-04-06 | 8 seeds + 22 signals written to futures-wheel-seeds-mtp.md. Mind The Product session this week |
