## Configuration

| Key | Value | Notes |
|-----|-------|-------|
| Slack bold | `*text*` single asterisk | `**` renders as literal characters |
| Slack URLs | Never bold | Breaks link rendering |
| Slack italics | `_text_` | Standard mrkdwn |
| Slack code | Backticks `` `code` `` | Triple for blocks |
| SVG ampersand | Escape as `&amp;` | Bare `&` → `xmlParseEntityRef` error |
| SVG validation | `xml.etree.ElementTree.parse()` | Run before every upload |
| Mermaid embed: style | Extract `<style>` → place at outer SVG root | Mermaid scopes CSS to `#my-svg` |
| Mermaid embed: wrapper | Wrap inner content in `<g id="my-svg">` | Without this, all nodes render black |
| Mermaid embed: transform | `<g transform>` wraps the `<g id="my-svg">` | Scale/translate on outer group |
| File upload primary | catbox.moe `reqtype=fileupload` | Permanent hosting |
| File upload fallback | litterbox.catbox.moe | 72h temporary |
| SVG constants module | `/workspace/ipc/files/jotf_svg_constants.py` | `import sys; sys.path.insert(0, '/workspace/ipc/files')` |
| SID meaning | Super Insight Digger | Hamid's coinage |
| Slack channel SID | `#C089UP13YDN` | Deep insight mining channel |
| Slack channel tested | `#C040UETETD5` | First Slack MCP test channel |
| JOTF site content path | `/workspace/extra/jedionthefly.com/data/sections/*.html` | Raw content files for GEO audit |
| Collisions editions path | `/workspace/extra/jedionthefly.com/collisions/editions/*.json` | Collision JSON files |
| GEO rubric source | `/home/node/.claude/skills/mind-trick/` | Citability scoring, AI crawler guidance |
